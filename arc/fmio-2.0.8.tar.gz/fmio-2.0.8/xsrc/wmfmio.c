/*
 * Copyright (c) 2001 Vladimir Popov <jumbo@narod.ru>
 *
 * $Id: wmfmio.c,v 1.19 2002/01/19 06:55:19 pva Exp $
 *
 * wmfmio - WindowMaker dock app, a non-setuid wrapper for
 * fmio, radiocard manipulation utility.
 *
 * Most of the code was taken from wmtune written by Soren <soren@leiden.org>.
 * The wmtune can be found at http://soren.org/linux/wmtune
 *
 * Original copyright below.
 */
/* Copyright (c) 1998 Soren (soren@leiden.org)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not,
 * write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
 *
 ****************************************************************
 */

#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <X11/xpm.h>

#include <time.h>

#include "wmgeneral.h"
#include "wmfmio-master.xpm"
#include "wmfmio-mask.xbm"

#define VERSION		"1.0"
char *RCFILE = "wmfmiorc";
char *FMIO = "fmio";
#define TMPBUFSIZE	128
#define DEF_DRV		"az1"
#define LIMBO		3
#define ON		1
#define OFF		0
#define TRUE		1
#define FALSE		0

const char exec_err[] = "%s execution error";

unsigned int max_presets;
unsigned int hour = 0, minute = 0;

struct tm *time_struct;
long current_time;

struct drivers_t {
	char *name;
	int maxvol;
} drivers[] = {
	{"az", 3},
	{"bmc", 15},
	{"er", 3},
	{"gti", 1},
	{"gtp", 1},
	{"mr", 1},
	{"rt", 10},
	{"rtII", 1},
	{"sae", 1},
	{"sf2d", 1},
	{"sfi", 10},
	{"sfr", 15},
	{"sf2r", 1},
	{"sf4r", 1},
	{"sp", 63},
	{"sqx", 1},
	{"stx", 1},
	{"svg", 1},
	{"tr", 63},
	{"tt", 7},
	{"zx", 16},
#ifdef linux
	{"v4l", 10},
	{"bktr", 10}
#else
	{"hx", 1},
	{"bktr", 1}
#endif /* linux */
	/* OpenBSD: Don't use br here, use audio/wmtune instead */
};

struct drivers_t drv = {NULL, 0};
int volume = 0;

char *myname;
char temp[TMPBUFSIZE + 1];

int i;

XEvent Event;

int but_stat = -1;
int but_timer = 0;

int auto_radio_on = OFF;
int auto_alarm_start = OFF;
int cmdline_preset = OFF;
int preset_count = 1;
int radio_status = OFF;
int alarm_state = 0;

struct presets_t {
	double freq;
} *presets;

void ParseCMDLine(int argc, char *argv[]);
int ParseRCFile(char *);
void ParseDRV(void);
void RadioOff(void);
void RadioOn(void);
void DrawDigitalFreq(void);
void DrawDigitalPreset(void);
void DrawDigitalTime(int, int);
void ButtonUp(int);
void ButtonDown(int);
void TimeUp(void);
void TimeDown(void);
void VolumeUp(void);
void VolumeDown(void);
void TuneUp(void);
void TuneDown(void);
void PresetHandler(int);
void ScanUp(void);
void ScanDown(void);
void OnPreset(void);
void GeneralFreqUpdate(void);
void FastFreqUpdate(void);
void TuneRadio(void);
int TestTune(void);
void TestFreq(void);

int
main(int argc,char *argv[]) {
	char *home;
	myname = argv[0];
	ParseCMDLine(argc, argv);

	home = getenv("HOME");
	if (home == NULL)
		home = ".";
	strncpy(temp, home, TMPBUFSIZE);
	temp[TMPBUFSIZE] = '\0';
	strncat(temp, "/.", TMPBUFSIZE);
	temp[TMPBUFSIZE] = '\0';
	strncat(temp, RCFILE, TMPBUFSIZE);
	temp[TMPBUFSIZE] = '\0';
	if ( ParseRCFile(temp) == 1 ) {
		strncpy(temp, "/etc/", TMPBUFSIZE);
		temp[TMPBUFSIZE] = '\0';
		strncat(temp, RCFILE, TMPBUFSIZE);
		temp[TMPBUFSIZE] = '\0';
		if (ParseRCFile(temp) == 1)
			errx(1, "~/.%s or /etc/%s not found", RCFILE, RCFILE);
	}

	if (cmdline_preset == ON)
		if (preset_count > max_presets || preset_count < 1)
			errx(1, "%s: invalid preset number: %d", RCFILE, preset_count);

	presets[0].freq = presets[preset_count].freq;

	openXwindow(argc, argv, wmfmio_master_xpm, wmfmio_mask_bits,
				wmfmio_mask_width, wmfmio_mask_height);

	AddMouseRegion(0,47,48,59,59); /* ON/OFF BUTTON */
	AddMouseRegion(1,5,35,16,44);  /* FINE TUNE UP (+) */
	AddMouseRegion(2,16,35,27,44); /* FINE TUNE DOWN (-) */
	AddMouseRegion(3,27,35,38,44); /* SCAN UP */
	AddMouseRegion(4,38,35,49,44); /* SCAN DOWN */
	AddMouseRegion(5,49,35,59,44); /* ALARM BUTTON */
	AddMouseRegion(6,23,48,35,59); /* LEFT PRESET SCAN BUTTON */
	AddMouseRegion(7,35,48,47,59); /* RIGHT PRESET SCAN BUTTON */

	if (auto_alarm_start == ON) {
		alarm_state = ON;
		DrawDigitalTime(hour,minute);
		copyXPMArea(117, 70, 5, 6, 6, 23); /* Light On */
		usleep(300000L);
		RedrawWindow();
	}

	if (auto_radio_on == ON) {
		RadioOn();
		RedrawWindow();
	}

	while (1) {
		while (XPending(display)) {
			XNextEvent(display, &Event);
			switch ( Event.type ) {
				case Expose:
					RedrawWindow();
					break;
				case DestroyNotify:
					XCloseDisplay(display);
					exit(0);
				case ButtonPress:
					i = CheckMouseRegion(Event.xbutton.x, Event.xbutton.y);
					switch (i) {
						case 0: /* ON/OFF BUTTON */
							ButtonDown(0);
							break;
						case 1: /* FINE TUNE UP (+) */
							ButtonDown(1);
							but_timer = 0;
							break;
						case 2: /* FINE TUNE DOWN (-) */
							ButtonDown(2);
							but_timer = 0;
							break;
						case 3: /* SCAN UP */
							ButtonDown(3);
							but_timer = 0;
							break;
						case 4: /* SCAN DOWN */
							ButtonDown(4);
							but_timer = 0;
							break;
						case 5: /* ALARM BUTTON */
							ButtonDown(5);
							break;
						case 6: /* LEFT PRESET SCAN BUTTON */
							ButtonDown(6);
							break;
						case 7: /* RIGHT PRESET SCAN BUTTON */
							ButtonDown(7);
						break;
					}
					but_stat = i;
					break;
				case ButtonRelease:
					ButtonUp(but_stat);
					if (i == but_stat && but_stat >= 0) {
						if  ( radio_status == OFF || alarm_state == LIMBO ) {
							if ( alarm_state == LIMBO ) {
								switch (i) {
									case 3: /* TIME UP */
										if ( !(but_timer >= 5) )
											TimeUp();
										break;
									case 4: /* TIME DOWN */
										if ( !(but_timer >= 5) )
											TimeDown();
										break;
									case 5: /* ALARM BUTTON SET */
										alarm_state = ON;
										/* Light On */
										copyXPMArea(117, 70, 5, 6, 6, 23);
										RedrawWindowXYWH(6, 23, 5, 6);
										break;
								}
							} else {
								if ( i == 0 )
									RadioOn();
							}
							but_stat = -1;
						} else {	
							switch ( i ) {
								case 0: /* ON/OFF BUTTON */
									RadioOff();
									break;
								case 1: /* FINE TUNE UP (+) */
									if ( but_timer < 5 )
										TuneUp();
									OnPreset();
									FastFreqUpdate();
									TestFreq();
									break;
								case 2: /* FINE TUNE DOWN (-) */
									if ( but_timer < 5 )
										TuneDown();
									OnPreset();
									FastFreqUpdate();
									TestFreq();
									break;
								case 3: /* SCAN UP */
									switch ( Event.xbutton.button ) {
										case 1:
											ScanUp();
											OnPreset();
											break;
										case 3:
											VolumeUp();
											break;
									}
									break;
								case 4: /* SCAN DOWN */
									switch ( Event.xbutton.button ) {
										case 1:
											ScanDown();
											OnPreset();
											break;
										case 3:
											VolumeDown();
											break;
									}
									break;
								case 5: /* ALARM BUTTON */
									if ( alarm_state == ON ) {
										alarm_state = OFF;
										copyXPMArea(76, 55, 34, 7, 6, 22);
										RedrawWindowXYWH(6, 22, 34, 7);
									} else {
										alarm_state = LIMBO;
										DrawDigitalTime(hour,minute);
									}
									break;
								case 6: /* LEFT PRESET SCAN BUTTON */
									PresetHandler(-1);
									break;
								case 7: /* RIGHT PRESET SCAN BUTTON */
									PresetHandler(1);
									break;
							}
						}
						but_stat = -1;
					}
				}
			} 

		if ( ((i == but_stat) && (but_stat >= 0)) && (radio_status == ON) ) {
			but_timer++;
			if( but_timer >= 5 ) {
				if ( alarm_state == LIMBO ) {
					switch ( i ) {
						case 3: /* TIME UP, AUTO-REPEAT */
							TimeUp();
							break;
						case 4: /* TIME DOWN, AUTO-REPEAT */
							TimeDown();
							break;
					}
				} else {
					switch ( i ) {
						case 1: /* FINE TUNE UP (+) AUTO-REPEAT */
							TuneUp();
							break;
						case 2: /* FINE TUNE DOWN (-) AUTO-REPEAT */
							TuneDown();
							break;
					}
				}
			}	
		}
		usleep(5000);
		if ( alarm_state == ON ) {
			current_time = time(NULL);
			time_struct = localtime((time_t *)&current_time);
			if( hour == time_struct->tm_hour )
				if ( minute == time_struct->tm_min ) {
					alarm_state = OFF;
					copyXPMArea(76, 55, 34, 7, 6, 22);
					RedrawWindowXYWH(6, 22, 34, 7);
					if ( radio_status == ON )
						RadioOff();
					else
						RadioOn();
				}
		}
	}

	return 0;
}

void
RadioOn(void) {
	radio_status = ON;
	if ( volume == 0 ) volume = 1;
	copyXPMArea(93, 90, 13, 5, 44, 9); 
	RedrawWindowXYWH(44, 9, 13, 5); /* MHz/kHz */
	copyXPMArea(96, 79, 11, 7, 45, 22);
	RedrawWindowXYWH(45, 22, 11, 7); /* FM/AM */
	GeneralFreqUpdate();
}

void
GeneralFreqUpdate(void) {
	TuneRadio();
	TestFreq();
	DrawDigitalPreset();
	DrawDigitalFreq();
}

void
FastFreqUpdate(void) {
	char buf[TMPBUFSIZE + 1];
	FILE *fp;

#ifdef VFSEPARATE
	snprintf(buf, TMPBUFSIZE, "%s -d %s -f %f", FMIO, drv.name,
			presets[0].freq);
#else
	snprintf(buf, TMPBUFSIZE, "%s -d %s -f %f -v %d", FMIO, drv.name,
			presets[0].freq, volume);
#endif
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if (fp == NULL)
		err(1, exec_err, FMIO);
	pclose(fp);
}

void
DrawDigitalTime(int hr, int min) {
    char temp[10];
    char *p = temp;
    int i, j, k=13;

    snprintf(temp, 9, "%02d:%02d", hr, min);
    temp[9] = '\0';

    for ( i = 0; i < 2; i++) {
        for ( j = 0; j < 2; j++) {
            copyXPMArea((*p-'0')*6 + 1, 79, 6, 7, k, 22);
            k += 6;
            p++;
        }
        if ( *p == ':' ) {
            copyXPMArea(61, 79, 2, 7, k, 22);
            k += 4;
            p++;
        }
    }
	RedrawWindowXYWH(13, 22, 27, 7);
}

void
PresetHandler(int preset_hint) {
	if ( preset_hint < 0 ) {
		if ( preset_count == 1 )
			preset_count = max_presets;
		else
			preset_count--;
	} else {
		if ( preset_count == max_presets )
			preset_count = 1;
		else
			preset_count++;
	}
	
	presets[0].freq = presets[preset_count].freq;

	GeneralFreqUpdate();
}

void
DrawDigitalPreset(void) {
	char temp[10];
	char *p = temp;
	int j = 0, k = 6;

	snprintf(temp, 9, "%02d", preset_count);
    	temp[9] = '\0';

	if ( *p == '0' ) {
		copyXPMArea(66, 79, 5, 7, k, 50);
		k += 6;
		j++;
		p++;
	}
	while ( j < 2 ) {
		copyXPMArea((*p-'0')*6 + 1, 79, 5, 7, k, 50);
		k += 6;
		p++;
		j++;
	}
	RedrawWindowXYWH(6, 50, 11, 7);
}
	
void
DrawDigitalFreq(void) {
	char temp[10];
	char *p = temp;
	int i = 5, j = 0, k = 6;

	snprintf(temp, 9, "%0f", presets[0].freq);
    	temp[9] = '\0';

	while ( j < i ) {
		if ( j == 0 && *p != '1' ) {
			copyXPMArea(76, 40, 6, 9, k, 7);
			k += 7;
			i--;
		}
		copyXPMArea((*p-'0')*7 + 1, 66, 7, 9, k, 7);
		k += 7;
		p++;
		if ( *p == '.' ) {
			copyXPMArea(71, 66, 3, 9, k, 7);
			k += 3;
			p++;
		}
		j++;
	}
	RedrawWindowXYWH(6, 7, 37, 9);
}

void
ScanUp(void) {
	char buf[TMPBUFSIZE + 1], *tmp;
	FILE *fp;
	float frequency = 0.0;

	copyXPMArea(114, 49, 13, 4, 44, 16); /* POSSIBLE SIGNAL LOSS (0) */
	RedrawWindowXYWH(44, 16, 13, 4); /* Test Freq Field Only */

	snprintf(buf, TMPBUFSIZE, "%s -d %s -W %.2f\n", FMIO, drv.name,
			(float)presets[0].freq);
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if ( fp == NULL )
		err(1, exec_err, FMIO);
	fgets(buf, TMPBUFSIZE, fp);
	buf[TMPBUFSIZE] = '\0';
	pclose(fp);

	tmp = strstr(buf, FMIO);
	if ( tmp != NULL ) {
		tmp += strlen(FMIO) + 2;
		tmp[6] = 0;
		frequency = atof(tmp);
	}

	if ( frequency != 0.0 ) {
		presets[0].freq = frequency;
		FastFreqUpdate();
		DrawDigitalFreq();

		if ( (i = TestTune()) != 0 ) {
			if ( i == 1 )
				/* SIGNAL & STEREO (1) */
				copyXPMArea(92, 100, 13, 4, 44, 16);
			else
				/* POSSIBLY MONO :)	(2) */
				copyXPMArea(92, 105, 13, 4, 44, 16);

			/* Test Freq Field Only */
			RedrawWindowXYWH(44, 16, 13, 4);
		}

		return;
	}

	while (1) {
		if ( (float)presets[0].freq != 108.0 )
			presets[0].freq += .01;
		else
			presets[0].freq = 88.0;

		FastFreqUpdate();
		DrawDigitalFreq();

		if ( (i = TestTune()) != 0 ) {
			if ( i == 1 )
				/* SIGNAL & STEREO (1) */
				copyXPMArea(92, 100, 13, 4, 44, 16);
			else
				/* POSSIBLY MONO :)	(2) */
				copyXPMArea(92, 105, 13, 4, 44, 16);

			/* Test Freq Field Only */
			RedrawWindowXYWH(44, 16, 13, 4);
			return;
		}
	}
}

void
ScanDown(void) {
	char buf[TMPBUFSIZE + 1], *tmp;
	FILE *fp;
	float frequency = 0.0;

	copyXPMArea(114, 49, 13, 4, 44, 16); /* POSSIBLE SIGNAL LOSS (0) */
	RedrawWindowXYWH(44, 16, 13, 4); /* Test Freq Field Only */

	snprintf(buf, TMPBUFSIZE, "%s -d %s -W -%.2f\n", FMIO, drv.name,
			(float)presets[0].freq);
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if (fp == NULL)
		err(1, exec_err, FMIO);
	fgets(buf, TMPBUFSIZE, fp);
	buf[TMPBUFSIZE] = '\0';
	pclose(fp);

	tmp = strstr(buf, FMIO);
	if (tmp != NULL) {
		tmp += strlen(FMIO) + 2;
		tmp[6] = 0;
		frequency = atof(tmp);
	}

	if (frequency != 0.0) {
		presets[0].freq = frequency;
		FastFreqUpdate();
		DrawDigitalFreq();

		if ((i = TestTune()) != 0) {
			if ( i == 1 )
				/* SIGNAL & STEREO (1) */
				copyXPMArea(92, 100, 13, 4, 44, 16);
			else
				/* POSSIBLY MONO :)	(2) */
				copyXPMArea(92, 105, 13, 4, 44, 16);

			/* Test Freq Field Only */
			RedrawWindowXYWH(44, 16, 13, 4);
		}

		return;
	}

	while (1) {
		if ( (float)presets[0].freq != 88.0 )
			presets[0].freq -= .01;
		else
			presets[0].freq = 108.0;

		FastFreqUpdate();
		DrawDigitalFreq();

		if ( (i = TestTune()) != 0 ) {
			if ( i == 1 )
				/* SIGNAL & STEREO (1) */
				copyXPMArea(92, 100, 13, 4, 44, 16);
			else
				/* POSSIBLY MONO :)	(2) */
				copyXPMArea(92, 105, 13, 4, 44, 16);

			/* Test Freq Field Only */
			RedrawWindowXYWH(44, 16, 13, 4);
			return;
		}
	}
}

void
ParseCMDLine(int argc,char *argv[]) {
	char *cmdline;
	int i;

	for (i = 1; i < argc; i++) {
		cmdline = argv[i];
		if ( *cmdline == '-' ) {
			switch ( cmdline[1] ) {
			case 'n':
				auto_radio_on = ON;
				break;
			case 't':
				auto_alarm_start = ON;
				hour = strtol(cmdline+3, (char **)NULL, 10);
				if ( (cmdline = strchr(cmdline+3, ':')) != NULL )
					minute = strtol(cmdline+1, (char **)NULL, 10);
				if (hour < 0 || hour > 23 || minute < 0 || minute > 59)
					errx(1, "Invalid timer setting: %2d:%2d", hour, minute);
				break;
			case 'p':
				preset_count = strtol(cmdline + 3, (char **)NULL, 10);
				cmdline_preset = ON;
				break;
			default:
				printf(
				"\nwmfmio v%s\n"
				"initial code by soren@leiden.org, "
				"design & art by warp@xs4all.nl\n" 
				"usage:\n"
				"\t-n\t\tturn radio on initially on startup\n"
				"\t-t <##:##>\tset timer on startup, military time\n"
				"\t-p <##>\t\tset startup preset # listed in %s file\n"
				"\t-h\t\tdisplay this screen\n"
				"\n", VERSION, RCFILE);
				exit(0);
			}
		}
	}
}

void
RadioOff(void) {
	char buf[TMPBUFSIZE + 1];
	FILE *fp;

	snprintf(buf, TMPBUFSIZE, "%s -d %s -v 0", FMIO, drv.name);
	buf[TMPBUFSIZE] = '\0';
	/* Do radio off */
	fp = popen(buf, "r");
	if ( fp == NULL )
		errx(1, exec_err, FMIO);
	pclose(fp);

	radio_status = OFF;	
	copyXPMArea(76, 40, 51, 13, 6, 7); 
	copyXPMArea(115, 55, 11, 7, 45, 22);
	copyXPMArea(83, 55, 11, 7, 6, 50);
	RedrawWindowXYWH(6, 50, 11, 7); /* Full Preset Field */
	RedrawWindowXYWH(6, 7, 51, 22); /* Full Upper Field */
}

void
TuneRadio(void) {
	char buf[512];
	FILE *fp;

#ifdef VFSEPARATE
	snprintf(buf, TMPBUFSIZE, "%s -d %s -f %f", FMIO, drv.name,
			presets[0].freq);
#else
	snprintf(buf, TMPBUFSIZE, "%s -d %s -f %f -v %d", FMIO, drv.name,
			presets[0].freq, volume);
#endif /* VFSEPARATE */
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if ( fp == NULL )
		err(1, exec_err, FMIO);

	pclose(fp);
}

void
ButtonDown(int button) {
	switch ( button ) {
		case 0: /* ON/OFF BUTTON */
			copyXPMArea(79, 100, 12, 11, 47, 48);
			RedrawWindowXYWH(47, 48, 12, 11);
			break;
		case 1: /* FINE TUNE UP (+) */
			copyXPMArea(0, 98, 11, 9, 5, 35);
			RedrawWindowXYWH(5, 35, 11, 9);
			break;
		case 2: /* FINE TUNE DOWN (-) */
			copyXPMArea(11, 98, 11, 9, 16, 35);
			RedrawWindowXYWH(16, 35, 11, 9);
			break;
		case 3: /* SCAN UP & TIME UP */
			copyXPMArea(22, 98, 11, 9, 27, 35);
			RedrawWindowXYWH(27, 35, 11, 9);
			break;
		case 4: /* SCAN DOWN & TIME DOWN */
			copyXPMArea(33, 98, 11, 9, 38, 35);
			RedrawWindowXYWH(38, 35, 11, 9);
			break;
		case 5: /* ALARM BUTTON */
			copyXPMArea(44, 98, 10, 9, 49, 35);
			RedrawWindowXYWH(49, 35, 10, 9);
			break;
		case 6: /* LEFT PRESET SCAN BUTTON */
			copyXPMArea(55, 100, 12, 11, 23, 48);
			RedrawWindowXYWH(23, 48, 12, 11);
			break;
		case 7: /* RIGHT PRESET SCAN BUTTON */
			copyXPMArea(67, 100, 12, 11, 35, 48);
			RedrawWindowXYWH(35, 48, 12, 11);
			break;
	}
}

void
ButtonUp(int button) {
	switch ( button ) {
		case 0: /* ON/OFF BUTTON */
			copyXPMArea(79, 88, 12, 11, 47, 48);
			RedrawWindowXYWH(47, 48, 12, 11);
			break;
		case 1: /* FINE TUNE UP (+) */
			copyXPMArea(0, 88, 11, 9, 5, 35);
			RedrawWindowXYWH(5, 35, 11, 9);
			break;
		case 2: /* FINE TUNE DOWN (-) */
			copyXPMArea(11, 88, 11, 9, 16, 35);
			RedrawWindowXYWH(16, 35, 11, 9);
			break;
		case 3: /* SCAN UP */
			copyXPMArea(22, 88, 11, 9, 27, 35);
			RedrawWindowXYWH(27, 35, 11, 9);
			break;
		case 4: /* SCAN DOWN */
			copyXPMArea(33, 88, 11, 9, 38, 35);
			RedrawWindowXYWH(38, 35, 11, 9);
			break;
		case 5: /* ALARM BUTTON */
			copyXPMArea(44, 88, 10, 9, 49, 35);
			RedrawWindowXYWH(49, 35, 10, 9);
			break;
		case 6: /* LEFT PRESET SCAN BUTTON */
			copyXPMArea(55, 88, 12, 11, 23, 48);
			RedrawWindowXYWH(23, 48, 12, 11);
			break;
		case 7: /* RIGHT PRESET SCAN BUTTON */
			copyXPMArea(67, 88, 12, 11, 35, 48);
			RedrawWindowXYWH(35, 48, 12, 11);
			break;
	}
}

void
TimeUp(void) {
	if ( minute == 59 ) {
		if ( hour == 23 )
			hour = 0;
		else
			hour++;
		minute = 0;
	} else minute++;

	DrawDigitalTime(hour, minute);
}

void
TimeDown(void) {
	if ( minute == 0 ) {
		if ( hour == 0 )
			hour = 23;
		else
			hour--;
		minute = 59;
	} else {
		minute--;
	}
	DrawDigitalTime(hour, minute);
}

void
VolumeUp(void) {
	char buf[TMPBUFSIZE + 1];
	FILE *fp;

	if ( volume < drv.maxvol )
		volume++;
	else
		return;

#ifdef VFSEPARATE
	snprintf(buf, TMPBUFSIZE, "%s -d %s -v %d", FMIO, drv.name, volume);
#else
	snprintf(buf, TMPBUFSIZE, "%s -d %s -f %f -v %d", FMIO, drv.name, presets[0].freq, volume);
#endif /* VFSEPARATE */
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if ( fp == NULL )
		err(1, exec_err, FMIO);
	pclose(fp);
}

void
VolumeDown(void) {
	char buf[TMPBUFSIZE + 1];
	FILE *fp;

	if ( volume > 0 )
		volume--;
	else
		return;

#ifdef VFSEPARATE
	snprintf(buf, TMPBUFSIZE, "%s -d %s -v %d", FMIO, drv.name, volume);
#else
	snprintf(buf, TMPBUFSIZE, "%s -d %s -f %f -v %d", FMIO, drv.name, presets[0].freq, volume);
#endif /* VFSEPARATE */
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if ( fp == NULL )
		err(1, exec_err, FMIO);
	pclose(fp);
}

void
TuneUp(void) {
	if ( (float)presets[0].freq != 108.0 )
		presets[0].freq += .01;
	else
		presets[0].freq = 88.0;

	DrawDigitalFreq();
}

void
TuneDown(void) {
	if ( (float)presets[0].freq != 88.0 )
		presets[0].freq -= .01;
	else
		presets[0].freq = 108.0;

	DrawDigitalFreq();
}

void
TestFreq(void) {
	switch ( TestTune() ) {
		case 0: /* POSSIBLE SIGNAL LOSS (0) */
			copyXPMArea(114, 49, 13, 4, 44, 16);
			break;
		case 1: /* SIGNAL & STEREO (1) */
			copyXPMArea(92, 100, 13, 4, 44, 16);
			break;
		case 2: /* POSSIBLY MONO :) (2) */
			copyXPMArea(92, 105, 13, 4, 44, 16);
			break;
	}
	RedrawWindowXYWH(44, 16, 13, 4);
}

void OnPreset(void) {
	int count = 1;

	while ( count < max_presets+1 ) {
		if ( (float)presets[0].freq == (float)presets[count].freq ) {
			preset_count = count;
			DrawDigitalPreset();
			return;
		}
		count++;
	}
}

int
TestTune(void) {
	char buf[TMPBUFSIZE + 1];
	FILE *fp;
	int rc = strlen(FMIO);

	snprintf(buf, TMPBUFSIZE, "%s -d %s -s", FMIO, drv.name);
	buf[TMPBUFSIZE] = '\0';
	fp = popen(buf, "r");
	if ( fp == NULL )
		err(1, exec_err, FMIO);
	fgets(buf, TMPBUFSIZE, fp);
	buf[TMPBUFSIZE] = '\0';
	pclose(fp);

	if ( !strncasecmp(&buf[rc+2], "mono", 4) )
		return 2;
	if ( !strncasecmp(&buf[rc+2], "stereo", 6) )
		return 1;

	return 0;
}

int
ParseRCFile(char *filename) {
	char temp[TMPBUFSIZE + 1], *p;
	FILE *fp;
	int ln = 1, count = 0;
	char *tokens = " \t\n";

	presets = malloc(sizeof(struct presets_t));

	if ( (fp = fopen(filename, "r")) == NULL )
		return 1;

	while( fgets(temp, TMPBUFSIZE, fp) ) {
		temp[TMPBUFSIZE] = '\0';
		if ( (p = strtok(temp, tokens)) != NULL ) {
			if ( (p = strchr(temp, '#')) != NULL )
				*p = '\0';

			if ( strlen(temp) != 0 ) {
				if ( !count ) {
					if ( strtol(temp, (char **)NULL, 10) ) {
						/* It's the first preset */
						count++;
					} else {
						drv.name = (char *)malloc(strlen(temp)+1);
						strcpy(drv.name, temp);
						ParseDRV();
					}
				}

				if ( count > 0 ) {
					presets = realloc(presets, (count+1)*sizeof(struct presets_t));
					sscanf(temp, "%lf", &presets[count].freq);
					if ( presets[count].freq < 88.0 ||
						 presets[count].freq > 108.0 ) {
						fprintf(stderr, "Invalid preset %s in %s line %d\n",
								temp, filename, ln);
						exit(1);
					}
				}
				count++;
			}
		}
		ln++;
	}
	fclose(fp);

	if ( drv.name == NULL ) {
		p = getenv("FMTUNER");
		if ( p && *p ) {
			drv.name = (char *)malloc(strlen(p)+1);
			strcpy(drv.name, p);
		} else {
			drv.name = (char *)malloc(strlen(DEF_DRV)+1);
			strcpy(drv.name, DEF_DRV);
		}
		ParseDRV();
	}

	max_presets = count-1;
	return 0;
}

void
ParseDRV(void) {
	int c = sizeof(drivers)/sizeof(drivers[0]);

	while ( c-- )
		if ( !strncmp(drv.name, drivers[c].name, strlen(drivers[c].name)) ) {
			drv.maxvol = drivers[c].maxvol;
			break;
		}

}
