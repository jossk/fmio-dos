/*
 * Copyright (c) 2002 Vladimir Popov <jumbo@narod.ru>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * fmrinit - this program initializes SF16-FMR cards. Needed only once at boot.
 */

#include <sys/param.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __FreeBSD__
#include <unistd.h>
#endif

#ifdef __QNXNTO__
#include <inttypes.h>
typedef uint8_t		u_int8_t;
typedef uint16_t	u_int16_t;
typedef uint32_t	u_int32_t;
#endif /* __QNXNTO__ */

#include <radio_drv.h>
#include <tc921x.h>

#define SF16FMR_FREQ_DATA_ON	(1 << 0)
#define SF16FMR_FREQ_CLOCK_ON	(1 << 1)
#define SF16FMR_FREQ_PERIOD_ON	(1 << 2)

#define SF16FMR_0x284		0x284
#define SF16FMR_0x384		0x384

#define DEF_PORT		SF16FMR_0x384

#define WR_PL_CL_DL(port, p, c, d)	OUTB(port, p * 0 | c * 0 | d * 0)
#define WR_PL_CL_DH(port, p, c, d)	OUTB(port, p * 0 | c * 0 | d * 1)
#define WR_PL_CH_DL(port, p, c, d)	OUTB(port, p * 0 | c * 1 | d * 0)
#define WR_PL_CH_DH(port, p, c, d)	OUTB(port, p * 0 | c * 1 | d * 1)

#define WR_PH_CL_DL(port, p, c, d)	OUTB(port, p * 1 | c * 0 | d * 0)
#define WR_PH_CL_DH(port, p, c, d)	OUTB(port, p * 1 | c * 0 | d * 1)
#define WR_PH_CH_DL(port, p, c, d)	OUTB(port, p * 1 | c * 1 | d * 0)
#define WR_PH_CH_DH(port, p, c, d)	OUTB(port, p * 1 | c * 1 | d * 1)

static void __tc921x_write_burst(u_int8_t, u_int32_t, struct tc921x_t *, int);

void
tc921x_write_addr(struct tc921x_t *c, u_int8_t addr, u_int32_t reg) {
	/* Finish previous transmission - PERIOD HIGH, CLOCK HIGH, DATA HIGH */
	WR_PH_CH_DH(c->port, c->period, c->clock, c->data);
	/* Start transmission - PERIOD LOW, CLOCK HIGH, DATA HIGH */
	WR_PL_CH_DH(c->port, c->period, c->clock, c->data);

	/*
	 * Period must be low when the register address transmission starts.
	 * Period must be high when the register data transmission starts.
	 * Do the switch in the middle of the address transmission.
	 */
	__tc921x_write_burst(4, addr, c, 0);
	__tc921x_write_burst(4, addr >> 4, c, 1);

	/* Writing data to the register */
	__tc921x_write_burst(TC921X_REGISTER_LENGTH, reg, c, 1);

	/* End of transmission - PERIOD goes LOW then HIGH */
	WR_PL_CH_DH(c->port, c->period, c->clock, c->data);
	WR_PH_CH_DH(c->port, c->period, c->clock, c->data);
}

static void
__tc921x_write_burst(u_int8_t length, u_int32_t data, struct tc921x_t *c, int p) {
	u_int8_t i;

	for (i = 0; i < length; i++) {
		if (data & (1 << i)) {
			WR_PH_CL_DH(c->port, c->period * p, c->clock, c->data);
			WR_PH_CH_DH(c->port, c->period * p, c->clock, c->data);
		} else {
			WR_PH_CL_DL(c->port, c->period * p, c->clock, c->data);
			WR_PH_CH_DL(c->port, c->period * p, c->clock, c->data);
		}
	}
}

#ifdef __FreeBSD__
const char *devio = "/dev/io";
static int fd = -1;

int
fbsd_get_ioperms(void) {
	if ((fd = open(devio, O_RDONLY)) < 0) {
		warn("%s open error", devio);
		return -1;
	}

	return 0;
}

int
fbsd_release_ioperms(void) {
	if (close(fd) < 0) {
		warn("%s close error", devio);
		return -1;
	}

	return 0;
}
#elif defined __QNXNTO__
int
qnx_iopl_acquire() {
	ThreadCtl(_NTO_TCTL_IO, 0);
	return 0;
}
#elif defined linux
int
os_ioperms(u_int32_t port, int no, int v) {
	if (ioperm(port, no, v) < 0) {
		warn("ioperm() error");
		return -1;
	}

	return 0;
}
#elif defined __OpenBSD__ || defined __NetBSD__
int
os_ioperms(u_int32_t port, int no, int v) {
	unsigned long iomap[32];
	int offset;
	unsigned long mask;
	struct i386_set_ioperm_args ioperms;

	memset(iomap, 0xFFFF, sizeof(iomap));
	if (v) {
		offset = port / 32;
		mask = no << port % 32;
		iomap[offset] ^= mask;
        }
	ioperms.iomap = iomap;
	if (sysarch(I386_SET_IOPERM, (char *)&ioperms) < 0) {
		warn("I386_SET_IOPERM error");
		return -1;
	}

	return 0;
}
#else
int
os_ioperms(u_int32_t port, int no, int v) {
	return -1;
}
#endif /* __FreeBSD__ */

int
radio_get_ioperms(u_int32_t port, int no) {
#ifdef __FreeBSD__
	return fbsd_get_ioperms();
#elif defined __QNXNTO__
	return qnx_iopl_acquire();
#else
	return os_ioperms(port, no, 1);
#endif
}

int
radio_release_ioperms(u_int32_t port, int no) {
#ifdef __FreeBSD__
	return fbsd_release_ioperms();
#elif defined __QNXNTO__
	return 0;
#else
	return os_ioperms(port, no, 0);
#endif
}

int
main(int argc, char **argv) {
	unsigned long data = 0ul;
	struct tc921x_t card = {
		DEF_PORT, SF16FMR_FREQ_PERIOD_ON,
		SF16FMR_FREQ_CLOCK_ON, SF16FMR_FREQ_DATA_ON
	};

	if (argc > 1)
		sscanf(argv[1], "%i", (int *)&card.port);

	if (card.port != SF16FMR_0x284 && card.port != SF16FMR_0x384)
		card.port = DEF_PORT;

	if (radio_get_ioperms(card.port, 1) < 0)
		return 1;

	/* Do a dummy data transfer to initialize the chip */
	data |= TC921X_D0_REF_FREQ_10_KHZ;
	data |= TC921X_D0_PULSE_SWALLOW_FM_MODE;
	data |= TC921X_D0_OSC_7POINT2_MHZ;
	data |= TC921X_D0_OUT_CONTROL_ON;
	tc921x_write_addr(&card, 0xD0, data);

	data  = TC921X_D2_IO_PORT_OUTPUT(4);
	tc921x_write_addr(&card, 0xD2, data);

	if (radio_release_ioperms(card.port, 1) < 0)
		return 1;

	return 0;
}
