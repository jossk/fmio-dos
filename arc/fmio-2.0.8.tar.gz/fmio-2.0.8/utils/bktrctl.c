/*
 * Copyright (c) 2001, 2002 Vladimir Popov <jumbo@narod.ru>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * bktrctl - holds /dev/tuner open all the time
 * $Id: bktrctl.c,v 1.1 2002/01/04 09:28:11 pva Exp $
 */

#if !defined __NetBSD__ && !defined __OpenBSD__ && !defined __FreeBSD__ && !defined linux
#error "This paltform is not supported"
#endif

#include <sys/param.h>

#include <sys/time.h>
#include <sys/resource.h>
#include <sys/stat.h>

#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>

#include <radio_drv.h>

#ifdef linux
#define	TUNER_DEVICE_1	"/dev/radio"
#define TUNER_DEVICE_2	"/dev/radio0"
#else
#define TUNER_DEVICE_1	"/dev/tuner"
#define TUNER_DEVICE_2	"/dev/tuner0"
#endif

#define SYMLINK_DEPTH	10

/*
 * LOG_ERR may spit error messages to console
 * Use LOG_WARNING to make bktrctl more quiet
 */
#ifndef LOG_DEFAULT
#define LOG_DEFAULT	LOG_ERR
#endif /* LOG_DEFAULT */

#ifndef OPEN_DEVTUNER_RDWR
#define OPEN_DEVTUNER_RDWR	0
#endif /* OPEN_DEVTUNER_RDWR */

static int fd = -1;

void
quit(void) {
	if (fd != -1)
		if (close(fd) < 0)
			syslog(LOG_DEFAULT, "/dev/tuner close error: %m");
	closelog();
}

int
mute(void) {
#ifdef linux
	struct video_audio va;

	va.audio = 0;
	va.flags = VIDEO_AUDIO_MUTE;
	va.volume = 0;

	if (ioctl(fd, VIDIOCSAUDIO, &va) < 0) {
		syslog(LOG_DEFAULT, "VIDIOCSAUDIO: %m");
#else
	unsigned int intern = 3;

	if (ioctl(fd, TVTUNER_SETCHNL, &intern) < 0) {
		syslog(LOG_DEFAULT, "TVTUNER_SETCHNL: %m");
		return -1;
	}
	if (ioctl(fd, TVTUNER_SETTYPE, &intern) < 0) {
		syslog(LOG_DEFAULT, "TVTUNER_SETTYPE: %m");
		return -1;
	}
	intern = AUDIO_INTERN;
	if (ioctl(fd, BT848_SAUDIO, &intern) < 0) {
		syslog(LOG_DEFAULT, "BT848_SAUDIO -> AUDIO_INTERN: %m");
		return -1;
	}
	intern = AUDIO_MUTE;
	if (ioctl(fd, BT848_SAUDIO, &intern) < 0) {
		syslog(LOG_DEFAULT, "BT848_SAUDIO -> AUDIO_MUTE: %m");
		return -1;
	}
	intern = 0;
	if (ioctl(fd, RADIO_SETMODE, &intern) < 0) {
		syslog(LOG_DEFAULT, "RADIO_SETMODE: %m");
#endif /* linux */
		return -1;
	}

	return 0;
}

int
open_device(void) {
	char buf[PATH_MAX], next_buf[PATH_MAX];
	struct stat s;
	int rfnb = 0; /* Length of file name read from readlink() */
	int depth = 0, found = 0;

	strncpy(buf, TUNER_DEVICE_1, PATH_MAX - 1);
	buf[PATH_MAX - 1] = '\0';

	/* Follow symlinks until the file is found */
	for (depth = 0; depth < SYMLINK_DEPTH; depth++) {

		if (lstat(buf, &s) < 0)
			break;

		if (!S_ISLNK(s.st_mode)) {
			found = 1;
			break;
		}

		rfnb = readlink(buf, next_buf, PATH_MAX - 1);
		if (rfnb < 0 || rfnb == 0)
			break;
		next_buf[rfnb] = '\0';

		strncpy(buf, next_buf, PATH_MAX - 1);
		buf[PATH_MAX - 1] = '\0';
	}

	/*
	 * Ok, TUNER_DEVICE_1 doesn't exist or is buried too deep
	 * Let's try last resort -- TUNER_DEVICE_2
	 */
	if (!found) {
		strncpy(buf, TUNER_DEVICE_2, PATH_MAX - 1);
		buf[PATH_MAX - 1] = '\0';
	}

#if OPEN_DEVTUNER_RDWR
	if ((fd = open(buf, O_RDWR)) < 0) {
#else
	if ((fd = open(buf, O_RDONLY)) < 0) {
#endif /* OPEN_DEVTUNER_RDWR */
		syslog(LOG_DEFAULT, "%s open error: %m", buf);
		return -1;
	}

	return mute();
}

int
main(int argc, char **argv) {
	int rfd;
	struct rlimit rlim;
	char *pn = NULL;

	pn = strrchr(argv[0], '/');
	if (pn == NULL)
		pn = argv[0];
	else
		pn++;

	if (getppid() != 1) {
		signal(SIGTTOU, SIG_IGN);
		signal(SIGTTIN, SIG_IGN);
		signal(SIGTSTP, SIG_IGN);

		if (fork() != 0)
			exit(errno);

		setsid();
	}

	getrlimit(RLIMIT_NOFILE, &rlim);
	for (rfd = 0; rfd < rlim.rlim_max; rfd++)
		close(rfd);

	openlog(pn, LOG_PID | LOG_CONS, LOG_USER);

	if (atexit(quit) < 0) {
		syslog(LOG_DEFAULT, "atexit(): %m");
		return (errno);
	}

	if (chdir("/") < 0) {
		syslog(LOG_DEFAULT, "cannot chdir(\"/\"): %m");
		return (errno);
	}

	if (open_device() < 0)
		return (errno);

	while (1)
		usleep(900000);

	return (0);
}
