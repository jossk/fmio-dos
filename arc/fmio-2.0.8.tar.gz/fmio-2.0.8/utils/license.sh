#!/bin/sh

TOPDIR=..

/usr/bin/find $TOPDIR -name fmio.c -print | /usr/bin/xargs /bin/cat | /usr/bin/head -23
